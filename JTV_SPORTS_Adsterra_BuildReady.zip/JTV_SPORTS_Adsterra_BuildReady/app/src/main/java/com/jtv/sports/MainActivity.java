package com.jtv.sports;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String ADSTERRA_LINK = "https://auctionr.org/4/336775353b902c1f9550ed98f199e020";
    private final int bg = Color.rgb(7,17,31);
    private final int panel = Color.rgb(18,35,55);
    private final int white = Color.WHITE;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(24));
        root.setBackgroundColor(bg);
        scroll.addView(root);

        TextView brand = new TextView(this);
        brand.setText("JTV SPORTS"); brand.setTextColor(white); brand.setTextSize(28);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(brand);
        TextView sub = new TextView(this);
        sub.setText("LIVE SPORTS NETWORK"); sub.setTextColor(Color.LTGRAY); sub.setTextSize(12);
        sub.setPadding(0, dp(3), 0, dp(20)); root.addView(sub);

        TextView notice = new TextView(this);
        notice.setText("স্বাগতম! আপনার অনুমোদিত লাইভ স্ট্রিম লিংক যোগ করে খেলা দেখুন।");
        notice.setTextColor(white); notice.setTextSize(15); notice.setPadding(dp(14),dp(16),dp(14),dp(16));
        notice.setBackgroundColor(panel); root.addView(notice, params());

        addSection(root, "CRICKET");
        addChannel(root, "Cricket Live", "এখানে আপনার বৈধ HLS / M3U8 stream URL বসাতে হবে", "");
        addSection(root, "FOOTBALL");
        addChannel(root, "Football Live", "এখানে আপনার বৈধ HLS / M3U8 stream URL বসাতে হবে", "");
        addSection(root, "OTHER SPORTS");
        addChannel(root, "Sports Live", "এখানে আপনার বৈধ HLS / M3U8 stream URL বসাতে হবে", "");

        Button ad = new Button(this);
        ad.setText("বিজ্ঞাপন দেখুন"); ad.setAllCaps(false);
        ad.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(ADSTERRA_LINK));
            startActivity(i);
        });
        LinearLayout.LayoutParams ap = params(); ap.topMargin = dp(22); root.addView(ad, ap);

        TextView foot = new TextView(this);
        foot.setText("JTV SPORTS • Version 1.0\nবিজ্ঞাপন দেখতে উপরের বাটনে চাপ দিন।");
        foot.setTextColor(Color.GRAY); foot.setTextSize(11); foot.setGravity(Gravity.CENTER);
        foot.setPadding(0,dp(24),0,0); root.addView(foot);
        setContentView(scroll);
    }

    private void addSection(LinearLayout root, String title) {
        TextView t = new TextView(this); t.setText(title); t.setTextColor(Color.rgb(255,90,80));
        t.setTextSize(13); t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(24), 0, dp(8)); root.addView(t);
    }
    private void addChannel(LinearLayout root, String title, String desc, String url) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14),dp(12),dp(14),dp(12)); card.setBackgroundColor(panel);
        TextView name = new TextView(this); name.setText(title); name.setTextColor(white);
        name.setTextSize(17); name.setTypeface(Typeface.DEFAULT, Typeface.BOLD); card.addView(name);
        TextView detail = new TextView(this); detail.setText(desc); detail.setTextColor(Color.LTGRAY);
        detail.setTextSize(12); detail.setPadding(0,dp(5),0,dp(10)); card.addView(detail);
        Button play = new Button(this); play.setText("Player খুলুন"); play.setAllCaps(false);
        play.setOnClickListener(v -> {
            if (url == null || url.trim().isEmpty()) {
                new android.app.AlertDialog.Builder(this).setTitle("Stream URL প্রয়োজন")
                    .setMessage("এই চ্যানেলের ভিডিও চালাতে অনুমোদিত M3U8 বা MP4 লিংক যোগ করতে হবে।")
                    .setPositiveButton("ঠিক আছে", null).show();
            } else {
                Intent i = new Intent(this, PlayerActivity.class); i.putExtra("url", url); i.putExtra("title", title); startActivity(i);
            }
        });
        card.addView(play); LinearLayout.LayoutParams cp = params(); cp.topMargin = dp(5); root.addView(card, cp);
    }
    private LinearLayout.LayoutParams params() { return new LinearLayout.LayoutParams(-1, -2); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
