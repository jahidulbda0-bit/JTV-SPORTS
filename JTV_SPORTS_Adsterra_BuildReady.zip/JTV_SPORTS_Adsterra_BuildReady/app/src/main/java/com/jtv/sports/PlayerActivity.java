package com.jtv.sports;

import android.app.Activity;
import android.os.Bundle;
import android.view.ViewGroup;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class PlayerActivity extends Activity {
    private ExoPlayer player;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        String url = getIntent().getStringExtra("url");
        PlayerView view = new PlayerView(this);
        view.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
        setContentView(view);
        if (url != null && !url.trim().isEmpty()) {
            player = new ExoPlayer.Builder(this).build();
            view.setPlayer(player);
            player.setMediaItem(MediaItem.fromUri(url));
            player.prepare(); player.play();
        }
    }
    @Override protected void onStop() { super.onStop(); if (player != null) { player.release(); player = null; } }
}
