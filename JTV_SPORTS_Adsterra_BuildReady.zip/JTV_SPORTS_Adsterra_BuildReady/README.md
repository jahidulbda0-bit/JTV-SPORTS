# JTV SPORTS (Android Native)

This project is configured to build a debug APK using GitHub Actions.

## Build on GitHub
1. Upload the *contents* of this folder to the root of your GitHub repository (including the hidden `.github` folder).
2. Commit the files to the `main` or `master` branch.
3. Open the repository's **Actions** tab and select **Build JTV SPORTS APK**.
4. Press **Run workflow** if it did not start automatically.
5. When the run succeeds, open the run and download the `JTV-SPORTS-debug-apk` artifact.

## Important
- The Adsterra Smartlink is opened only after the user taps **বিজ্ঞাপন দেখুন**. It is not forced on app launch.
- The supplied Smartlink is included as provided: `https://auctionr.org/4/336775353b902c1f9550ed98f199e020`.
- The channel cards are placeholders. Add authorized HLS/M3U8 or MP4 stream URLs in `MainActivity.java` before expecting live video to play.
- This project does not contain an AdMob SDK.
- This is source code; the APK is produced by the GitHub Actions workflow, not included in this ZIP.
